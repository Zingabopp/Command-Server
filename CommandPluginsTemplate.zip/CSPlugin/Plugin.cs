﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommandPluginLib;

namespace $safeprojectname$
{
    public class Plugin : ICommandPlugin
    {
        // Name that identifies this plugin as a source/destination
        public string PluginName => "$safeprojectname$";
        // ICommandPlugin.PluginName of the Command-Server plugin it communicates with
        public string CounterPart => "BS_CIPlugin";

        private Dictionary<string, Action<object, string>> _commands;
        /// <summary>
        /// Dictionary of commands this plugin can receive.
        /// </summary>
        public Dictionary<string, Action<object, string>> Commands
        {
            get
            {
                if (_commands == null)
                    _commands = new Dictionary<string, Action<object, string>>();
                return _commands;
            }
        }

        /// <summary>
        /// Add supported commands to the Commands Dictionary.
        /// </summary>
        private void BuildCommands()
        {
            // OnRequestStatus will be called when we receive a message with the flag "GETSTATUS"
            Commands.Add("GETSTATUS", OnRequestStatus);
        }

        /// <summary>
        /// Message ready to send to Beat Saber.
        /// </summary>
        public event Action<object, MessageData> MessageReady;

        /// <summary>
        /// Initialize the plugin. Run when loaded into the Command-Server.
        /// </summary>
        public void Initialize()
        {
            // Set the level of messages you want to see on the console.
            Logger.LogLevel = LogLevel.Trace;
            // Build the Dictionary of supported commands and their actions.
            BuildCommands();
        }

        /// <summary>
        /// Received message from the server.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e">MessageData received</param>
        public void OnMessage(object sender, MessageData e)
        {
            Logger.Trace($"{e.Source} says: {e.Data}");

            // Check if the command is supported, if it is execute the command.
            if (_commands.ContainsKey(e.Flag))
                _commands[e.Flag](sender, e.Data);
        }

        /// <summary>
        /// Called when a message is received with the flag "GETSTATUS".
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="m"></param>
        public void OnRequestStatus(object sender, string m)
        {
            Logger.Info($"Counterpart says: {m}");
            // Send a message back.
            SendStatus($"Hello, are you having fun?");
        }

        public void SendStatus(string message)
        {
            // Create the MessageData to send back to Beat Saber.
            var msg = new MessageData(
                PluginName,
                CounterPart,
                message,
                "STATUS");

            // Let the server know we have a message ready.
            MessageReady(this, msg);
        }
    }
}
