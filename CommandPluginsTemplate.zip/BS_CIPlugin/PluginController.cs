﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.SceneManagement;
using CommandPluginLib;

namespace $safeprojectname$
{
    class PluginController : MonoBehaviour, ICommandPlugin
    {
        // Name that identifies this plugin as a source/destination
        public string PluginName => Plugin.PluginName;
        // ICommandPlugin.PluginName of the Command-Server plugin it communicates with
        public string CounterPart => "CS_Plugin"; 

        private Dictionary<string, Action<object, string>> _commands;
        /// <summary>
        /// Dictionary of commands this plugin can receive.
        /// </summary>
        public Dictionary<string, Action<object, string>> Commands
        {
            get
            {
                if (_commands == null)
                    _commands = new Dictionary<string, Action<object, string>>();
                return _commands;
            }
        }

        /// <summary>
        /// Add supported commands to the Commands Dictionary.
        /// </summary>
        private void BuildCommands()
        {
            // ReceiveCounterPartStatus will be called when we receive a message with the flag "STATUS"
            Commands.AddSafe("STATUS", ReceiveCounterPartStatus);
        }

        /// <summary>
        /// Messages to be sent to the server.
        /// </summary>
        public event Action<object, MessageData> MessageReady;

        public void Initialize()
        {
            // Not used
        }

        public void OnMessage(object sender, MessageData e)
        {
            Logger.Trace($"Received message:\n{e.ToString()}");
            if (e.Destination == PluginName)
                Commands[e.Flag](sender, e.Data);
            else
                Logger.Debug($"Discarding message, we are not the destination");
        }

        public void Awake()
        {
            BuildCommands();
            SceneManager.activeSceneChanged += SceneManagerOnActiveSceneChanged;
        }

        public void ReceiveCounterPartStatus(object sender, string m)
        {
            Logger.Info($"Counterpart says: {m}");
        }

        public void RequestCounterPartStatus(string message)
        {
            var msg = new MessageData(
                PluginName,
                CounterPart,
                message,
                "GETSTATUS");
            MessageReady(this, msg);
        }

        private void SceneManagerOnActiveSceneChanged(Scene oldScene, Scene newScene)
        {
            try
            {



                if (newScene.name == "Menu")
                {
                    //Code to execute when entering The Menu
                    RequestCounterPartStatus("Hi, I'm in the menu");

                }

                if (newScene.name == "GameCore")
                {
                    //Code to execute when entering actual gameplay
                    RequestCounterPartStatus("Hi, I'm in GameCore");

                }
            }catch (Exception ex)
            {
                Logger.Exception("Exception in OnActiveSceneChanged:", ex);
            }


        }

    }
}
