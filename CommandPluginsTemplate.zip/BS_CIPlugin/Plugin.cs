﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Media;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using IllusionPlugin;
using $safeprojectname$.Util;
using CommandPluginLib;


namespace $safeprojectname$
{
    public class Plugin : IPlugin
    {
        public static string PluginName = "$safeprojectname$";
        public string Name => PluginName;
        public string Version => "0.0.1";

        bool doesCIExist;

        public void OnApplicationStart()
        {
            // Set the level of messages you want to see on the console.
            Logger.LogLevel = LogLevel.Trace; 

            //Checks if the Command-Interface plugin exists.
            doesCIExist = IllusionInjector.PluginManager.Plugins.Any(x => x.Name == "Command-Interface");
            if (doesCIExist)
            {
                Logger.Debug("Command-Interface exists, starting loader");
                SceneManager.sceneLoaded += SceneManager_sceneLoaded;

                // Create the loader to start looking for the Command-Interface
                var loader = new GameObject($"{PluginName}Loader").AddComponent<Loader>();
                // Don't destroy the loader if the scene changes.
                GameObject.DontDestroyOnLoad(loader.gameObject);
                // Call OnLoadSuccess when the loader finds the Command-Interface
                loader.LoadSuccess += OnLoadSuccess;

            }
            else
                Logger.Error("Command-Interface not found, unable to start");

        }

        /// <summary>
        /// Loader found the Command-Interface and added our controller as a Component. Initialize the plugin with the server.
        /// </summary>
        /// <param name="loader"></param>
        /// <param name="server"></param>
        /// <param name="OBSC"></param>
        public void OnLoadSuccess(GameObject loader, ICommandPlugin server, ICommandPlugin OBSC)
        {
            Logger.Debug("Loader was successful, registering plugin with Command-Interface");
            // Create a message to register the plugin with the server.
            var initMsg = new MessageData(PluginName, "Command-Interface", Plugin.PluginName, "REGISTER");
            // Call Command-Interface's OnMessage, passing it our plugin and the initialization message.
            server.OnMessage(OBSC, initMsg);
            // Destroy the loader, we don't need it anymore.
            GameObject.Destroy(loader);
        }

        private void SceneManager_sceneLoaded(Scene scene, LoadSceneMode arg1)
        {
            //Create GameplayOptions/SettingsUI if using either
            if (scene.name == "Menu")
                UI.BasicUI.CreateUI();

        }

        public void OnApplicationQuit()
        {
            SceneManager.sceneLoaded -= SceneManager_sceneLoaded;
        }

        public void OnLevelWasLoaded(int level)
        {

        }

        public void OnLevelWasInitialized(int level)
        {
        }

        public void OnUpdate()
        {


        }

        public void OnFixedUpdate()
        {
        }
    }
}
