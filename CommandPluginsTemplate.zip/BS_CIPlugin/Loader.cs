﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine.SceneManagement;
using UnityEngine;
using CommandPluginLib;

namespace $safeprojectname$
{
    /// <summary>
    /// This class is used to find the Command-Interface and register your plugin with it.
    /// </summary>
    class Loader : MonoBehaviour
    {
        bool loaded;

        public void Start()
        {
            Logger.Debug("Loader started");
            loaded = false;
            StartCoroutine(LoadToServer());
        }

        /// <summary>
        /// Loop until the server is found as long as we're not in GameCore.
        /// </summary>
        /// <returns></returns>
        public IEnumerator<WaitForSeconds> LoadToServer()
        {
            yield return new WaitForSeconds(.5f);
            GameObject server = null;
            // Loop until the plugin is loaded.
            while (!loaded)
            {

                if ((SceneManager.GetActiveScene().name != "GameCore"))
                {
                    Logger.Trace("Attempting to find server GameObject");
                    server = GameObject.FindObjectsOfType<GameObject>().Where(c => c.name.Contains("CIHTTPServer")).FirstOrDefault();
                    if (server != null)
                    {
                        Logger.Debug($"Found server GameObject: {server.name}");
                        // Add our plugin as a component of Command-Interface's GameObject.
                        var pluginController = server.AddComponent<PluginController>();
                        loaded = true;

                        // Let our Plugin class know we loaded the plugin and pass it the Command-Interface's ICommandPlugin component along with our own ICommandInterface.
                        LoadSuccess(this.gameObject,
                            server.GetComponents<ICommandPlugin>().Where(c => c.PluginName == "Command-Interface").FirstOrDefault(),
                            pluginController
                            );

                    }
                    else
                    {
                        Logger.Trace("Server not found, waiting 3 sec");
                        yield return new WaitForSeconds(3);
                    }
                }
                else
                    yield return new WaitForSeconds(3);


            }
        }

        public event Action<GameObject, ICommandPlugin, ICommandPlugin> LoadSuccess;
    }
}
